export const MagicSeparator = '###MAGIC###'
